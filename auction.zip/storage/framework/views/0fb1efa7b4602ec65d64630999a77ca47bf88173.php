<?php $__env->startSection('content'); ?>

    <!-- Main content -->
    <section class="content">
      <!-- /.row -->
      <div class="row">

      	<div class="col-md-12">
          <!-- general form elements -->
          <div class="box box-success ">
            <div class="box-header with-border">
              <h3 class="box-title">Add Stock</h3>
              <div class="box-tools pull-right">
                <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-plus"></i>
                </button>
              </div>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
            	<form role="form" method="POST" action="<?php echo e(route('stocks.store')); ?>">
            	<?php echo csrf_field(); ?>
            		<div class="col-md-2">
		                <div class="form-group">
		                  <label for="s_vendor_code">Vendor Code</label>
		                  <select name="vendor_code" class="form-control select2" id="s_vendor_code" style="width: 100%;" required>
			                  <option selected="selected" disabled>Vendor Code</option>
			                  <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			                  	<option value="<?php echo e($vendor->id); ?>"><?php echo e($vendor->vendor_code); ?></option>
			                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			                </select>
		                </div>

		            </div>
	              	<div class="col-md-5">
		                <div class="form-group">
		                  <label for="s_vendor_name">Vendor</label>
		                  <select name="vendor_name" class="form-control select2" id="s_vendor_name" style="width: 100%;" required>
			                  <option selected="selected" disabled>Select Vendor</option>
			                  <?php $__currentLoopData = $vendors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			                  	<option value="<?php echo e($vendor->id); ?>"><?php echo e($vendor->first_name); ?> <?php echo e($vendor->last_name); ?></option>
			                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			              </select>
		                </div>
		            </div>

		            <div class="col-md-5">
		                <div class="form-group">
		                  <label for="s_date"> Date </label>
		                  <input type="date" name="date" class="form-control" id="s_date" placeholder="Date" required>
		                </div>
		            </div>
		            <div class="col-md-4">
		                <div class="form-group">
		                  <label for="s_form_no">Form No *</label>
		                  <input type="text" name="form_no" class="form-control" id="s_form_no" placeholder="Form No" required>
		                </div>
		            </div>
		            <div class="col-md-4">
		                <div class="form-group">
		                  <label for="s_commission">Commission *</label>
		                  <input type="number" name="commission" class="form-control" id="s_commission" placeholder="Commission" required>
		                </div>
		            </div>
		            <div class="col-md-4">
		                <div class="form-group">
		                  <label for="s_item_no">Item Number *</label>
		                  <input type="text" name="item_no" class="form-control" id="s_item_no" placeholder="Item Number" required>
		                </div>
		            </div>
		            <div class="col-md-6">
		                <div class="form-group">
		                  <label for="s_quantity">Quantity </label>
		                  <input type="number" name="quantity" class="form-control" id="s_quantity" placeholder="Quantity" required>
		                </div>
		            </div>
		            <div class="col-md-6">
		                <div class="form-group">
		                  <label for="s_description">Description</label>
		                  <textarea type="text" name="description" class="form-control" id="s_description" placeholder="Description" required></textarea> 
		                </div>
		            </div>
		            <div class="col-md-3">
		                <div class="form-group">
		                  <label for="s_reserve">Reserve</label>
		                  <input type="number" name="reserve" class="form-control" id="s_reserve" placeholder="Reserve">
		                </div>
		            </div>
			        <div class="col-md-12">
			        	<div class="box-footer">
		              		<button type="submit" class="btn btn-primary">Submit</button>
		            	</div>
			        </div>    
            	</form>
            </div>
            <!-- /.box-body -->
          </div>
        </div>

      </div>
    </section>
    <!-- /.content -->


<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
	<script type="text/javascript">
		$('#s_vendor_code').on('change', function() {
			var oldval = $('#s_vendor_name').val();
			var newval = this.value;
			if(oldval!=newval)
		  		$('#s_vendor_name').val(this.value).trigger('change');
		});
		$('#s_vendor_name').on('change', function() {
			var oldval = $('#s_vendor_code').val();
			var newval = this.value;
			if(oldval!=newval)
		  		$('#s_vendor_code').val(this.value).trigger('change');
		});
	</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('backend.layouts.app',['title'=>'Stocks'], \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>